package gh14

func bar() string {
	s := `foo
bar`
	return s
}
