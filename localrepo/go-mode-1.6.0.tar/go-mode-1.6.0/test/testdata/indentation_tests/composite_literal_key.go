func _() {
	Foo{
		Bar:
	}
}
