package gh11

func init() {
	g(someSillyLongExpression(param1, param2, param3),
		"boo")
	x := 42
}
