package gh9

func x() string {
	s := f(`
foo`)
	return s
}
