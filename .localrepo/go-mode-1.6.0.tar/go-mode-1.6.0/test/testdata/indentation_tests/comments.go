package comments

func _() {
	if foo {
		X /* why */ /* do this */
	}
}
