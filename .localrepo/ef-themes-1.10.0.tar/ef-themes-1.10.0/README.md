# Ef (εὖ) themes for GNU Emacs

IMAGES HERE: <https://protesilaos.com/emacs/ef-themes-pictures>.

The `ef-themes` are a collection of light and dark themes for GNU Emacs
whose goal is to provide colorful ("pretty") yet legible options for
users who want something with a bit more flair than the `modus-themes`
(also designed by me).

+ Package name (GNU ELPA): `ef-themes`
+ Official manual: <https://protesilaos.com/emacs/ef-themes>
+ Change log: <https://protesilaos.com/emacs/ef-themes-changelog>
+ Sample pictures: <https://protesilaos.com/emacs/ef-themes-pictures>
+ Git repositories:
  + GitHub: <https://github.com/protesilaos/ef-themes>
  + GitLab: <https://gitlab.com/protesilaos/ef-themes>
+ Backronym: Eclectic Fashion in Themes Hides Exaggerated Markings,
  Embellishments, and Sparkles.
